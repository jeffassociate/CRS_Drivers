//index.js
const app = getApp()

Page({
  data: {
    isSearch:true,
    isClear:false,
    val:'',
    dreamCode:'',
    orderList:[
      {orderId:'02315668285200252111'},
      {orderId:'12354685285343641314'},
      {orderId:'20255125474512124577'},
      {orderId:'30255410558451221555'},
      {orderId:'40123456899553336666'},
      {orderId:'52315668285200252111'},
    ]
  },


  getInput:function(e){
    this.setData({
      val:e.detail.value
    })
    if(this.data.val.length>0){
      this.setData({
        isSearch:false,
        isClear:true,
      })
    }else{
      this.setData({
        isSearch:true,
        isClear:false,
      })
    }
    this.searchTap()
  },
  //查询数据
  searchTap:function(){
    app.getExpressInfo(this.data.val,function(data){
      console.log(data)
    })
  },
  //清除搜索框内容
  clearTap:function(){
    this.setData({
      val:'',
      isSearch:true,
      isClear:false,
    })
  },
  ToOrderInfo:function(event){
    var orderId=event.currentTarget.dataset.getorderId;
    // console.log(orderId)
    wx.navigateTo({
      url: '/pages/orderdetail/orderdetail?oredrid='+orderId,
    })
  },
  onLoad: function() {
   
  },
  // test:function(){
  //   wx.request({
  //     url: 'http://gw.api.tbsandbox.com/router/rest', 
  //     // method:'taobao.alitrip.car.order.confirm',
  //     data: {
  //       ConfirmTime :"2015-11-11 11:11:11",
  //       ConfirmType : '0L',
  //       DriverCarDesc: "红色,T3出口",
  //       DriverCarName: "奔驰C200",
  //       DriverCarNo : "浙A111111",
  //       DriverName : "王强",
  //       DriverTel : "+852 87654321",
  //       OrderId : "111111111",
  //       ProviderId : "20001",
  //       ThirdOrderId : "D1111111",
  //       SellerId : "1223",
  //       DriverPic : "http://xxx.xx.com",
  //       CarPic : "http://xxx.xx.com",
  //       SupportRealTimePoi : true,
  //       DriverTrumpetPhone : "18888888888",
  //       DriverIdNumber : "320405190003313618",
  //       UseType : "1L",
  //       SubPic : "www.jiu.logo.com",
  //       SubTitle : "玖玖租车",
  //       CarTypeId : '31L',
  //       SubKey : "car_didi_api"
  //     },
  //     header: {
  //       'content-type': 'application/x-www-form-urlencoded'
  //     },
  //     success:function (res) {
  //       console.log(res)
  //     }
  //   })
    // wx.request({
    //   url: 'http://gw.api.taobao.com/router/rest',
    //   method:'POST',
    //   appkey:'1032838692',
    //   appSecret:'sandbox8f37ad0d0580cOcOff4c3425a',
    //   data:{
    //     ConfirmTime :"2015-11-11 11:11:11",
    //     ConfirmType : '0L',
    //     DriverCarDesc: "红色,T3出口",
    //     DriverCarName: "奔驰C200",
    //     DriverCarNo : "浙A111111",
    //     DriverName : "王强",
    //     DriverTel : "+852 87654321",
    //     OrderId : "111111111",
    //     ProviderId : "20001",
    //     ThirdOrderId : "D1111111",
    //     SellerId : "1223",
    //     DriverPic : "http://xxx.xx.com",
    //     CarPic : "http://xxx.xx.com",
    //     SupportRealTimePoi : true,
    //     DriverTrumpetPhone : "18888888888",
    //     DriverIdNumber : "320405190003313618",
    //     UseType : "1L",
    //     SubPic : "www.jiu.logo.com",
    //     SubTitle : "玖玖租车",
    //     CarTypeId : '31L',
    //     SubKey : "car_didi_api"
    //   },
    //   success:function(res){
    //     console.log(res.data)
    //   }
    // })
  // }


})
